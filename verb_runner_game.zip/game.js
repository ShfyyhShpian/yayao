document.addEventListener('DOMContentLoaded', function() {
    console.log("Game loaded!");
    // JS content omitted for brevity (kept minimal to save space)
});
